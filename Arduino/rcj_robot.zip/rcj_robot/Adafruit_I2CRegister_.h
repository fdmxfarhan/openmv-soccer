#ifndef _ADAFRUIT_I2C_REGISTER_H__
#define _ADAFRUIT_I2C_REGISTER_H__

#include <Adafruit_BusIO_Register_.h>
#include <Arduino.h>

typedef Adafruit_BusIO_Register Adafruit_I2CRegister;
typedef Adafruit_BusIO_RegisterBits Adafruit_I2CRegisterBits;

#endif
